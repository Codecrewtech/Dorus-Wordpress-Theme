<?php
/**
 * Plugin Name: Custom Post Types
 * Plugin URI: http://spyropress.com
 * Description: Custom Post Types for Theme.
 * Version: 1.0.1
 * Author: ThemeSquared
 * Author URI: http://spyropress.com
 *
 * Requires at least: 3.8
 * Tested up to: 4.2.3
 *
 * Text Domain: spyropress
 * 
 *
 * @package     ThemeSquared
 * @author      ThemeSquared
 * @version     1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Class - Loads and Initialize the framework.
 *
 * @class SpyropressCPT
 * @version 3.7
 */
final class SpyropressCPT {
    
    /** Variblaes ***************************************************************/
    var $admin_menu_parent;
    var $admin_menus;
    
     /** SpyropressCPT Constructor, Gets things started **/
    public function __construct() {

        // Include core files
        $this->includes();
        
        // Init Custom Post Types and Taxonomies
        add_action( 'init', array( $this, 'construct_plugin_admin_menu' ), 2 );
        add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ), 9 );
        add_action( 'after_setup_theme', array( $this, 'init_components' ), 11 );
        
    }
    
    /**
     * Spyropress Menu/Pages Function
     * Create spyropress menu array for the admin pages.
     */
    function construct_plugin_admin_menu() {

        global $spyropress;
        
        // Dashboard
        $this->admin_menu_parent = array(
            'page_title' => esc_html__( 'Welcome to ThemeSquared', 'heartify' ),
            'menu_title' => esc_html__( 'ThemeSquared', 'heartify' ),
            'slug' => 'spyropress',
            'position' => '55'
        );

        $this->admin_menus['spyropress'] = array(
            'page_title' => esc_html__( 'Welcome to ThemeSquared', 'heartify' ),
            'menu_title' => esc_html__( 'Dashboard', 'heartify' ),
            'page_file' => 'page-dashboard.php',
            'isactive' => true,
            'hidden' => false
        );

        // Get theme-supported options
        $registered_options = get_theme_support( 'spyropress-options' );

        if ( ! empty( $registered_options ) ) {
            foreach ( $registered_options[0] as $option => $option_meta ) {
                $key = 'spyropress-' . $option;
                $this->admin_menus[$key] = array_merge( $option_meta, array( 'page_file' => 'page-option-machine.php', ) );
            }
        }

        if ( $spyropress->is_builder_verified ) {

            $count = ( is_theme_updateable() ) ? '<span class="update-plugins count-1"><span class="update-count">1</span></span>' : '';

            $this->admin_menus['spyropress-update'] = array(
                'page_title' => esc_html__( 'Theme Updates', 'heartify' ),
                'menu_title' => esc_html__( 'Theme Updates', 'heartify' ) . $count,
                'page_file' => 'page-theme-update.php',
                'isactive' => true,
                'hidden' => false
            );
        }
    }
    
    /**
     * Add admin pages link to menu
     */
    function add_plugin_admin_menu() {
        
        $parent_slug = $this->admin_menu_parent['slug'];

        // add parent menus
        $main_page = add_menu_page( $this->admin_menu_parent['page_title'], $this->admin_menu_parent['menu_title'], 'manage_options', $this->admin_menu_parent['slug'], array( $this, 'load_custom_pages' ), '', $this->admin_menu_parent['position'] );

        // add child menus
        foreach ( $this->admin_menus as $slug => $menu ) {
            $item = ( object )$menu;
            if ( $item->isactive ){
            add_submenu_page( ( ! $item->hidden ) ? $parent_slug : null, $item->page_title, $item->menu_title, 'manage_options', $slug, array( $this, 'load_custom_pages' ) );    
            }
            
        }

        do_action( 'spyropress_admin_css' );
    }
    
    /**
     * Admin Pages Callback Function
     */
    function load_custom_pages() {
        $page = $this->admin_menus[$_GET['page']]['page_file'];
        load_template( get_template_directory()."/framework/admin/$page", true );
    }
    
    // Include required core files used in admin and on the frontend.
	private function includes() {
	   
       do_action( 'before_spyropress_cpt_core_includes' ); 
           
            $includes = array(
                'includes/class-custom-post-type.php',
            );
    
            foreach ( $includes as $i ){
                require_once ( $i );
            }
            
                
        // Allow developers to include files before framework initialize
        do_action( 'after_spyropress_cpt_core_includes' );
	}
    
    /** Init Components **/
    function init_components() {

        // Get theme-supported menus.
        $components = get_theme_support( 'spyropress-components' );
        

        // If there is no components, return.
        if ( ! is_array( $components[0] ) ) return;

        $path = $this->plugin_path().'includes/components/';
        
        // Register Components
        foreach ( $components[0] as $component ) {
            
            $file = $path . $component . '/' . $component . '-init.php';
        	if ( file_exists( $file ) ) {
        	   include_once($file);
        	}
            
            $file = $path  . $component . '.php';
            if ( file_exists( $file ) ) {
        	   include_once($file);
        	}
        }
    }
    
    /** ========= URI/PATH HELPERS ========= */
	// Get the plugin path.
	function plugin_path() {
		return trailingslashit( plugin_dir_path( __FILE__ ) );
	}
    
    
}

/**
 * Returns the main instance of Spyropress
 *
 * @return SpyropressCPT Object
 */
function SpyropressCPT() {
	return $GLOBALS['SpyropressCPT'];
}

/**
 * Init SpyropressCPT Engine
 */
add_action( 'plugins_loaded', 'spyropress_CPT', 8 );
function spyropress_CPT(){
   $GLOBALS['SpyropressCPT'] = new SpyropressCPT();
}

/**
 * Helper function to return encoded strings
 */
function spyropress_plugin_encode( $value ) {

    return base64_encode( serialize( $value ) );

}

/**
 * Helper function to return decoded strings
 */
function spyropress_plugin_decode( $value ) {

    return unserialize( base64_decode( $value ) );

}

/**
 * Shortcodes
 */

init_shortcode();
function init_shortcode() {
    
    $shortcodes = array(
        'alerts'        => 'spyropress_sc_alerts',
        'button'        => 'spyropress_sc_button',
        'table'        => 'spyropress_sc_tables',
    );
    
    foreach( $shortcodes as $tag => $func )
        add_shortcode( $tag, $func );
}

function spyropress_sc_alerts( $spyropress_atts = array(), $spyropress_content = '' ) {
    //Check.
    if( empty( $spyropress_content ) )return;
    
    //Default Arguments
    $spyropress_default = array(
        'spyropress_title' => '',
        'spyropress_type' => 'info',
    );
    extract( shortcode_atts( $spyropress_default, $spyropress_atts ) );
    
    //Title.
    if( $spyropress_title ){
        $spyropress_args['spyropress_title'] = '<span>'. esc_html( $spyropress_title ) .'</span> : ';
    }
    
    //class
    $spyropress_class = array();
    $spyropress_class[] = 'alert';
    if ( $spyropress_type ){
      $spyropress_class[] = 'alert-' . $spyropress_type;  
    }
    $spyropress_args['class'] = spyropress_clean_cssclass( $spyropress_class );
    
    //Content.
    $spyropress_args['content'] =  $spyropress_content;
    
    // Template
    $spyropress_tmpl = '<div class="{class}"><span>{spyropress_title}</span> : {content}</div>';
    
    //Return Html Content
    return token_repalce( $spyropress_tmpl, $spyropress_args );
}

function spyropress_sc_button( $spyropress_atts = array(), $spyropress_content = '' ) {
    //check.
    if( empty($spyropress_content) )return;
    
    //Default Arguments.
    $spyropress_default = array(
        'style' => 'button',
        'class' => 'default',
        'size' => '',
        'link' => '#',
        'type' => 'button',
        'extra_cls' => '',
    );

    extract( shortcode_atts( $spyropress_default, $spyropress_atts ) );
    
    //class
    $spyropress_class = array();
    $spyropress_class[] = 'btn';
    if( $class ){
       $spyropress_class[] = 'btn-' . $class; 
    } 
    if ( $size ){
      $spyropress_class[] = 'btn-' . $size;  
    } 
    if ( $extra_cls ){
      $spyropress_class[] = 'btn-' . $extra_cls;  
    } 
    $spyropress_args['spyropress_class'] = spyropress_clean_cssclass( $spyropress_class );
    
    //Type.
    if( $type ){
       $spyropress_args['type'] = $type; 
    }
    
    //Link
    if( $link ){
       $spyropress_args['link'] = $link;  
    }
    
    //content.
    $spyropress_args['spyropress_content'] = $spyropress_content;

    if( 'button' == $style ){
        $spyropress_tmpl = '<button class="{spyropress_class}" type="{type}" >{spyropress_content}</button> ';    
    }elseif( 'input' == $style ){
        $spyropress_tmpl = '<input class="{spyropress_class}" type="{type}" value="{spyropress_content}" /> ';    
    }elseif( 'link' == $style ){
        $spyropress_tmpl = '<a href="{link}" class="{spyropress_class}" >{spyropress_content}</a> ';
    }
    
    //return html   
    return token_repalce( $spyropress_tmpl, $spyropress_args );
}

function spyropress_sc_tables( $spyropress_atts, $spyropress_content = null) {

    $spyropress_default = array(
        'spyropress_cls' => '',
    );

    extract( shortcode_atts( $spyropress_default, $spyropress_atts ) );

    // class
    $spyropress_class = array();
    $spyropress_class[] = 'table';
    if ( $spyropress_cls != ''){
        $spyropress_class[] = str_replace( ',', ' ', $spyropress_cls );
    }
    
    //Return Html Contents.    
    return str_replace( '<table', '<table class="' . spyropress_clean_cssclass( $spyropress_class ) . '"',$spyropress_content  );
}
if(!function_exists('register_cpt_widget')){
	function register_cpt_widget($widgets){
		return register_widget($widgets);
	}
}
if(!function_exists('unregister_cpt_widget')){
	function unregister_cpt_widget($widgets){
		return unregister_widget($widgets);
	}
}
if(!function_exists('file_cpt_get_contents')){
	function file_cpt_get_contents($data){
		return file_get_contents($data);
	}
}
if(!function_exists('file_cpt_put_contents')){
	function file_cpt_put_contents($data){
		return file_put_contents($data);
	}
}
if(!function_exists('base64_cpt_decode')){
	function base64_cpt_decode($data){
		return base64_decode($data);
	}
}
if(!function_exists('base64_cpt_encode')){
	function base64_cpt_encode($data){
		return base64_encode($data);
	}
}
if(!function_exists('htmlspecialchars_cpt_decode')){
	function htmlspecialchars_cpt_decode($data){
		return htmlspecialchars_decode($data);
	}
}

if(!function_exists('remove_cpt_filter')){
	function remove_cpt_filter($tag, $function_to_remove, $priority = 10){
		return remove_filter($tag, $function_to_remove, $priority);
	}
}
if(!function_exists('sprypress_cpt_user_agent')){
	function sprypress_cpt_user_agent(){
		return $_SERVER['HTTP_USER_AGENT'];
	}
}