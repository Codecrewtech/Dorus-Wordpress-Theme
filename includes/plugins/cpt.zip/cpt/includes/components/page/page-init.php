<?php
/**
 * Page Component
 * 
 * @package		SpyroPress
 * @category	Components
 */

class SpyropressPage extends SpyropressComponent {

    private $path;

    function __construct() {

	$this->path = dirname(__FILE__);
        add_action( 'spyropress_register_taxonomy', array( $this, 'register' ) );
    }

    function register() {

        // Init Post Type
        $post = new SpyropressCustomPostType( 'Page' );
        $menus = wp_get_nav_menus();
        $menu_options = array();

        if ( isset( $menus ) && count( $menus ) > 0 ) {
            foreach ( $menus as $menu ) {
                $menu_options[$menu->term_id] = $menu->name;
            }
        }

        // Add Meta Boxes
        $meta_fields['options'] = array(
        
            array(
                'label' => __( 'Slider', 'spyropress' ),
                'type' => 'heading',
                'slug' => 'options'
            ),          

            array(
                'label' => __( 'OnePage Menu', 'spyropress' ),
                'id' => 'spyropress_onepage_menu',
                'type' => 'select',
                'class' => 'page_template one-page-php',
                'options' => $menu_options
            ),
			
			array(
				'label' => __( 'Top Section Bucket', 'spyropress' ),
				'id' => 'spyropress_bucket',
				'type' => 'select',
				'desc' => __( 'Select a Module Backet for page top section.', 'spyropress' ),
				'options' => spyropress_get_buckets()
			),
            
            array(
                'label' => esc_html__( 'Page Breadcrumb', 'sonno' ),
                'type' => 'sub_heading'
            ),
            
            array(
        		'label' => __( 'Page Breadcrumb', 'spyropress' ),
        		'id' => 'page_breadcrumb',
                'type' => 'checkbox',
                'options' => array(
                    1 => __( 'Enable or disable page breadcrumb.', 'spyropress' ),
                )
        	),
            
            array(
        	    'label' => __( 'Page Breadcrumb Background', 'spyropress' ),
                'desc' => __( 'Choose background style for Page bradcrumb background.', 'spyropress' ),
        	    'id' => 'page_breadcrumb_bg',
                'type' => 'background'
            ),
            
            array(
        	    'label' => __( 'Page Breadcrumb', 'spyropress' ),
                'desc' => __( 'Insert short description about the page', 'spyropress' ),
        	    'id' => 'page_breadcrumb_dec',
                'type' => 'textarea',
                'rows' => 3
            ),
            
           array(
        	   'label' => __( 'Page Comments', 'spyropress' ),
        	   'id' => 'spyropress_comments',
               'type' => 'checkbox',
               'options' => array(
                    '1' => __( 'Disable page Comments.', 'spyropress' ),
               )
            ),
            
            array(
                'label' => esc_html__( 'Footer Subscribe', 'sonno' ),
                'type' => 'sub_heading'
            ),
            
            array(
        		'label' => __( 'Footer Subscribe', 'spyropress' ),
        		'id' => 'footer_subscribe',
                'type' => 'checkbox',
                'options' => array(
                    1 => __( 'Enable or disable footer subscribe.', 'spyropress' ),
                )
        	),
        
        );
		
        $post->add_cpt_meta_box( 'page_options', __( 'Page Options', 'spyropress' ), $meta_fields, '_page_options', false, 'normal', 'high' );
    }
}

/**
 * Init the Component
 */
new SpyropressPage();