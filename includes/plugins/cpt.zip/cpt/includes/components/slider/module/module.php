<?php
/**
 * Module: Slider
 * View Slider on page.
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Slider extends SpyropressBuilderModule {

    public function __construct() {
        
        // Widget variable settings.
        $this->path = dirname(__FILE__);
        $this->cssclass = 'spyropress-slider';
        $this->description = __( 'View Slider on page.', 'spyropress' );
        $this->id_base = 'spyropress-slider';
        $this->name = __( 'Slider', 'spyropress' );

        // Fields
        $this->fields = array(
            
            array(
                'label' => __( 'Slider' , 'spyropress' ),
                'id' => 'spyropress_slider_id',
                'type' => 'select',
                'options' => $this->spyropress_get_sliders()
            ),
            
            array(
                'label' => __( 'Animation', 'spyropress' ),
                'type' => 'toggle',
            ),
            
                array(
            		'label' => __( 'Animation', 'spyropress' ),
            		'id' => 'spyropress_animation',
                    'type' => 'select',
                    'options' => spyropress_get_options_animation()
            	),
                
                array(
                    'label' => __( 'Delay', 'spyropress' ),
                    'id' => 'spyropress_delay',
                    'type' => 'text'
                ),
                
            array(
        		'type' => 'toggle_end'
        	) 
        );

        $this->create_widget();
    }
    
    /**
     * Data Source - Sliders
     */
    function spyropress_get_sliders() {
        
        $sliders = array();
        
        if ( ! post_type_exists( 'slider' ) ) return $sliders;
        
        // get posts
        $args = array(
            'post_type' => 'slider',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'asc'
        );
        $posts = get_posts( $args );
        if ( !empty( $posts ) ) {
            foreach ( $posts as $post ) {
                $sliders[$post->ID] = $post->post_title;
            }
        }
    
        return $sliders;
    }

    function widget( $spyropress_args, $spyropress_instance ) {

        // extracting info
        extract( $spyropress_args ); extract( $spyropress_instance );

        //Required View File
        include $this->get_view(); 
    }
}
//Register Module Class Spyropress_Module_Slider
spyropress_builder_register_module( 'Spyropress_Module_Slider' );