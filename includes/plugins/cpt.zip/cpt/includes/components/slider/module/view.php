<?php
//shortcode.
if( $spyropress_slider_id ){
    echo '<div class="row"  '. spyropress_build_atts( array( 'animation' => esc_attr( $spyropress_animation ) , 'animation-delay' => esc_attr( $spyropress_delay ) ), 'data-' ) .'>'. do_shortcode( '[slider id='. esc_attr( $spyropress_slider_id ) .']' ) .'</div>';
} 