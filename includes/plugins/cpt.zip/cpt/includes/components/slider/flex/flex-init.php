<?php

/**
 * Flex Slider
 * Related functions
 */

/**
 * Slides Options
 */
function get_flexslides_setting() {
    
    $slides = array(
        array(
            'label'  => __( 'Slides', 'spyropress' ),
            'type' => 'heading',
            'icon' => 'general',
            'slug' => 'instruction'
        ),

        array(
    		'label' => __( 'Slide', 'spyropress' ),
    		'type' => 'repeater',
            'id' => 'spyropress_slides',
            'fields' => array(
            
                array(
                    'label' => __( 'Heading', 'spyropress' ),
                    'id' => 'spyropress_heading',
                    'type' => 'text',
                ),
                
                array(
                    'label' => __( 'Image', 'spyropress' ),
                    'id' => 'spyropress_image',
                    'type' => 'upload',
                ),

                array(
                    'label' => __( 'Content', 'spyropress' ),
                    'id' => 'spyropress_content',
                    'type' => 'textarea',
                    'rows' => 3
                ),
                
                array(
                    'label' => __( 'Buttons', 'spyropress' ),
                    'type' => 'repeater',
                    'id' => 'spyropress_btns',
                    'item_title' => 'title',
                    'fields' => array(
                        array(
                            'label' => __( 'Title', 'spyropress' ),
                            'id' => 'spyropress_title',
                            'type' => 'text',
                        ),
                        
                        array(
                            'label' => __( 'Link', 'spyropress' ),
                            'id' => 'spyropress_link',
                            'type' => 'text',
                        ),
                        
                        array(
                            'label' => __( 'Button Type', 'spyropress' ),
                            'id' => 'spyropress_btn_type',
                            'type' => 'select',
                            'options' => array(
                                'btn-default' => __( 'default', 'spyropress' ),
                                'btn-primary' => __( 'Primary', 'spyropress' ),
                                'btn-success' => __( 'Success', 'spyropress' ),
                                'btn-info' => __( 'Info', 'spyropress' ),
                                'btn-warning' => __( 'Warning', 'spyropress' ),
                                'btn-danger' => __( 'Danger', 'spyropress' ),
                                'btn-link' => __( 'Link', 'spyropress' ),
                                'btn-quaternary' => __( 'Quaternary', 'spyropress' ),
                                'btn-tertiary' => __( 'Tertiary', 'spyropress' ),
                                'btn-secondary' => __( 'Secondary', 'spyropress' ),
                            ),'std' => 'btn-default'
                        )
                    )
                )
            )
        )
    );

    return $slides;
}


/**
 * Generate Markup
 */
function flexslider_shortcode_handler( $spyropress_slider_id, $spyropress_slides, $spyropress_settings = '' ) {

    $spyropress_out = '';
    $spyropress_out .= '<div class="col-md-offset-1 col-md-10"><div class="flexslider special-slider"><ul class="slides">';
    foreach ( $spyropress_slides as $spyropress_slide_item ) {
        $spyropress_out .= '<li>';
        
        //Slider Image.
        if( isset( $spyropress_slide_item['spyropress_image'] ) ){
             $spyropress_out .='
             <div class="slider-img">
                <img src="'. esc_url( $spyropress_slide_item['spyropress_image'] ) .'" alt="" />
             </div>';               
        }
        
        $spyropress_out .= '<div class="slider-content">';
        
            //Slider Heading.
            if( isset( $spyropress_slide_item['spyropress_heading'] ) ){
                 $spyropress_out .='
                 <div class="page-header">
                    <h1>'. wp_kses( $spyropress_slide_item['spyropress_heading'], array( 'small' => array() ) ) .'</h1>
                 </div>';               
            }
            
            //Slider Contents.
            if( isset( $spyropress_slide_item['spyropress_content'] ) ){
                 $spyropress_out .='<p>'. esc_html( $spyropress_slide_item['spyropress_content'] ) .'</p>';               
            }
            
            //Slider Buttons.
            if( isset( $spyropress_slide_item['spyropress_btns'] ) ){
                foreach( $spyropress_slide_item['spyropress_btns'] as $spyropress_btn ){
                    $spyropress_out .='<a class="btn '. esc_attr( $spyropress_btn['spyropress_btn_type'] ) .'" href="'. esc_url( $spyropress_btn['spyropress_link'] ) .'" >'. esc_html( $spyropress_btn['spyropress_title'] ) .'</a>';   
                }               
            }
                            
        $spyropress_out .= '</div></li>';
    }
    $spyropress_out .= '</ul>
                        <div class="direction-nav hidden-sm">
                            <div class="next">
                                <a><img src="'. esc_url( assets_img( 'right-arrow.png' ) ) .'" alt="" /></a>
                            </div>
                            <div class="prev">
                                <a><img src="'. esc_url( assets_img( 'left-arrow.png' ) ) .'" alt="" /></a>
                            </div>
                        </div></div></div>';

    return $spyropress_out;
}