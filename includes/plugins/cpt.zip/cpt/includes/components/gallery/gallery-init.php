<?php

/**
 * Gallery Component
 *
 * @package		SpyroPress
 * @category	Components
 */

class SpyropressGallery extends SpyropressComponent {

    private $path;
    
    function __construct() {

        $this->path = dirname(__FILE__);
        add_action( 'spyropress_register_taxonomy', array( $this, 'register' ) );
        add_shortcode( 'gallery',  array( $this, 'shortcode_handler' ) );
        add_filter( 'builder_include_modules', array( $this, 'register_module' ) );
    }

    function register() {

        // Init Post Type
        $args = array(
            'description'   => __( 'Gallery post type', 'spyropress' ),
            'supports'      => array( 'title', 'thumbnail' ),
            'menu_icon' => 'dashicons-portfolio'
        );
        $post = new SpyropressCustomPostType( __( 'Gallery', 'spyropress' ), '', $args );
        
        // Add Taxonomy
        $post->add_taxonomy( __( 'Category', 'spyropress' ), 'gallery_category', __( 'Gallery Categories', 'spyropress' ), array( 'hierarchical' => true ) );
        
   }
    
   function register_module( $modules ) {

        $modules[] = $this->path . '/gallery/gallery.php';

        return $modules;
    }
    
}

/**
 * Init the Component
 */
new SpyropressGallery();