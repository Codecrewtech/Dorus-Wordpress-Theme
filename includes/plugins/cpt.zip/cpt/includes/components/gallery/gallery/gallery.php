<?php

/**
 * Module: Gallery
 * Gallery Builder
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Gallery extends SpyropressBuilderModule {

    /**
     * Constructor
     */
    public function __construct() {

        // Widget variable settings
        $this->path = dirname( __FILE__ );
        $this->cssclass = 'gallery';
        $this->description = __( 'Gallery Builder', 'spyropress' );
        $this->id_base = 'gallery';
        $this->name = __( 'Gallery', 'spyropress' );

        // Fields
        $this->fields = array (
            
           array(
                'label' => esc_html__( 'Columns', 'spyropress' ),
                'id' => 'columns',
                'class' => 'template view section-full',
                'type' => 'select',
                'options' => array(
                    2 => esc_html__( '2 Column', 'spyropress' ),
                    3 => esc_html__( '3 Column', 'spyropress' ),
                    4 => esc_html__( '4 Column', 'spyropress' ),
                )
           ),
             
           array(
                'label' => __( 'Number of items', 'spyropress' ),
                'id' => 'limit',
                'type' => 'range_slider',
                'std' => 6
            ),
            
            array(
                'label' => __( 'Category', 'spyropress' ),
                'id' => 'cat',
                'type' => 'multi_select',
                'options' => spyropress_get_taxonomies( 'gallery_category' )
            ),
        );

        $this->create_widget();
    }


    function widget( $spyropress_args, $spyropress_instance ) {

        // extracting info
        extract( $spyropress_args ); extract( $spyropress_instance );
        
        // get view to render
        include $this->get_view();
    }
    
    function spyropress_query( $spyropress_atts, $spyropress_content = null ) {

        $spyropress_default = array (
            'post_type' => 'gallery',
            'limit' => -1,
            'columns' => 4,
            'pagination' => false,
            'callback' => array( $this, 'spyropress_generate_gallery_item' ),
        );
        $spyropress_atts = wp_parse_args( $spyropress_atts, $spyropress_default );

        if ( ! empty( $spyropress_atts['cat'] ) ) {

            $spyropress_atts['tax_query']['relation'] = 'OR';
            if ( ! empty( $spyropress_atts['cat'] ) ) {
                $spyropress_atts['tax_query'][] = array(
                    'taxonomy' => 'gallery_category',
                    'field' => 'slug',
                    'terms' => $spyropress_atts['cat'],
                    );
                unset( $spyropress_atts['cat'] );
            }
        }

        if ( $spyropress_content )
            return token_repalce( $spyropress_content, spyropress_query_generator( $spyropress_atts ) );

        return spyropress_query_generator( $spyropress_atts );
    }
    
    // Item HTML Generator
    function spyropress_generate_gallery_item( $post_ID, $spyropress_atts ) {
        
        $spyropress_image = get_image( array( 'echo' => false, 'class' => 'img-responsive' ) );
        //check image.
        if( empty( $spyropress_image ) )return;
        
        $spyropress_item_tmpl = '';
        // item tempalte
        $spyropress_item_tmpl .= 
        '<div class="'. esc_attr( $spyropress_atts['column_class'] ) .'">
            <div class="gallery-item" data-mfp-src="'. esc_url( get_image( array( 'echo' => false, 'type' => 'src' ) ) ) .'">
                '. $spyropress_image .'
                <div class="gi-overlay">
                    <i class="fa fa-search"></i>
                </div>
            </div>
        </div>';

        return $spyropress_item_tmpl;
    }
       
}
//Register Module Class Spyropress_Module_Gallery.
spyropress_builder_register_module( 'Spyropress_Module_Gallery' );