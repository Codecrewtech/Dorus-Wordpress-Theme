<?php
// Setup Instance for view
$spyropress_instance = spyropress_clean_array( $spyropress_instance );

//Print Html Contents.
echo '<div class="gallery-content">'. $this->spyropress_query( $spyropress_instance, '{content}' ) .'</div>';