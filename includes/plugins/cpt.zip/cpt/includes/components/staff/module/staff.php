<?php

/**
 * Module: Staff
 * Display a list of staff
 *
 * @author 		SpyroSol
 * @category 	BuilderModules
 * @package 	Spyropress
 */

class Spyropress_Module_Staff extends SpyropressBuilderModule {

    public function __construct() {

        // Widget variable settings.
        $this->path = dirname( __FILE__ );
        $this->description = __( 'Display a list of staff.', 'sonno' );
        $this->id_base = 'spyropress_staff';
        $this->name = __( 'Our Team', 'sonno' );
        
        // Fields
        $this->fields = array(
        
            array(
                'label' => esc_html__( 'Columns', 'spyropress' ),
                'id' => 'columns',
                'class' => 'template view section-full',
                'type' => 'select',
                'options' => array(
                    2 => esc_html__( '2 Column', 'spyropress' ),
                    3 => esc_html__( '3 Column', 'spyropress' ),
                    4 => esc_html__( '4 Column', 'spyropress' ),
                )
            ),
            
            array(
                'label' => __( 'Number of Items', 'sonno' ),
                'id' => 'limit',
                'type' => 'range_slider',
                'std' => 4,
                'max' => 20
            ),
            
            
            array(
                'label' => __( 'Portfolio Category', 'sonno' ),
                'id' => 'cat',
                'type' => 'multi_select',
                'options' => spyropress_get_taxonomies( 'staff_category' )
            )
            
        );

        $this->create_widget();
    }

   function widget( $spyropress_args, $spyropress_instance ) {

        // extracting info
        extract( $spyropress_args ); extract( $spyropress_instance );
        
        // get view to render
        include $this->get_view();
    }
    
    function spyropress_query( $spyropress_atts, $spyropress_content = null ) {

        $spyropress_default = array (
            'post_type' => 'staff',
            'limit' => -1,
            'pagination' => false,
            'callback' => array( $this, 'spyropress_generate_staff_item' ),
            'row' => false,
            'column_class' => 'text-center',
            'columns' => 4
        );
        $spyropress_atts = wp_parse_args( $spyropress_atts, $spyropress_default );

        if ( ! empty( $spyropress_atts['cat'] ) ) {

            $spyropress_atts['tax_query']['relation'] = 'OR';
            if ( ! empty( $spyropress_atts['cat'] ) ) {
                $spyropress_atts['tax_query'][] = array(
                    'taxonomy' => 'staff_category',
                    'field' => 'slug',
                    'terms' => $spyropress_atts['cat'],
                    );
                unset( $spyropress_atts['cat'] );
            }
        }

        if ( $spyropress_content )
            return token_repalce( $spyropress_content, spyropress_query_generator( $spyropress_atts ) );

        return spyropress_query_generator( $spyropress_atts );
    }

    function spyropress_generate_staff_item( $post_ID, $spyropress_atts ) {
        
        //post meta data value
        $spyropress_info = get_post_meta( $post_ID, '_mate_info', true );
        
        //Social Icons.
        $spyropress_socials_icons = '';
        if( isset( $spyropress_info['spyropress_social_icons'] ) ):
            foreach( $spyropress_info['spyropress_social_icons'] as $spyropress_social_icon ){
                $spyropress_socials_icons .= '<li><a href="'. esc_url( $spyropress_social_icon['spyropress_link'] ) .'"><i class="fa fa-'. esc_attr( $spyropress_social_icon['spyropress_network'] ) .'"></i></a></li>';
            }
            $spyropress_socials_icons = '<ul class="team-social">'. $spyropress_socials_icons .'</ul>';    
        
        endif; 
        
        //Desgination
        $spyropress_terms = get_the_terms( $post_ID, 'designation' );
        $spyropress_terms_name =  array();
        if( !empty( $spyropress_terms ) && !is_wp_error( $spyropress_terms ) ) {
            foreach( $spyropress_terms as $spyropress_term )
                $spyropress_terms_name[] = $spyropress_term->name;
        }
        
        //Animation
        $spyropress_animation = isset( $spyropress_info['spyropress_animation'] )? $spyropress_info['spyropress_animation'] : '';
        $spyropress_delay = isset( $spyropress_info['spyropress_delay'] )? $spyropress_info['spyropress_delay'] : '';
            
        // item tempalte
        return '
        <div class="'. esc_attr( $spyropress_atts['column_class'] ) .'">
            <div class="team-staff" '. spyropress_build_atts( array( 'animation' => esc_attr( $spyropress_animation ) , 'animation-delay' => esc_attr( $spyropress_delay ) ) ) .'>
                '. get_image( array( 'class' => 'img-responsive center-block', 'echo' => false ) ) .'
                <h4>'. get_the_title() .'</h4>
                <p>'. join( ', ', $spyropress_terms_name ) .'</p>
                '. $spyropress_socials_icons .'
            </div>
        </div>';
        
    }

}
//Register Module Class Spyropress_Module_Staff.
spyropress_builder_register_module( 'Spyropress_Module_Staff' );