<?php
// Setup Instance for view
$spyropress_instance = spyropress_clean_array( $spyropress_instance );
  
//content.
echo  $this->spyropress_query( $spyropress_instance, '{content}' );