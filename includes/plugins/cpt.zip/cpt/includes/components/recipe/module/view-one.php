<?php
    // Setup Instance for view
    $spyropress_instance = spyropress_clean_array( $spyropress_instance );
    $spyropress_instance['callback'] = array( $this, 'spyropress_generate_items_two' );
    $spyropress_instance['row'] = false;
    $spyropress_instance['columns'] = $spyropress_columns;
    
    //Get Post Contents.
    $spyropress_output = $this->spyropress_query( $spyropress_instance );

?>
<div class="featured-recipie">
    <?php
        //Module Title. 
        if( $spyropress_title ){
            echo '<hr/><h3>'. esc_html( $spyropress_title ) .'</h3>';
        }
        echo '<div class="row"><div class="featured-recipies">'. $spyropress_output['content'] .'</div></div>'; //Module Contents. 
    ?>
</div> 
        