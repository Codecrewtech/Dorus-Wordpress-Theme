<?php
    // Setup Instance for view
    $spyropress_instance = spyropress_clean_array( $spyropress_instance );
    $spyropress_instance['callback'] = array( $this, 'spyropress_generate_items_three' );
    $spyropress_instance['columns'] = 2;
    $spyropress_instance['divider'] = true;
    
    //Get Post Contents.
    $spyropress_output = $this->spyropress_query( $spyropress_instance );

?>
<div class="recipie-content">
    <?php echo $spyropress_output['content']; //Module Contents. ?>
</div> 
        
        