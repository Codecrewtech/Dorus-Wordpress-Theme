<?php
/**
 * Module: Recipes
 * Add Recipe items into the page layout wherever needed.
 */
class Spyropress_Module_Recipes extends SpyropressBuilderModule {
    
    public function __construct() {
        
        // Widget variable settings.
        $this->path = dirname( __FILE__ );
        $this->cssclass = 'spyropress_recipes';
        $this->description = __( 'Add Recipe items into the page layout wherever needed.', 'spyropress' );
        $this->id_base = 'spyropress_recipes';
        $this->name = __( 'Recipes', 'spyropress' );
        
        //template.
        $this->templates['view-two']   = array( 'view' => 'view-two.php', 'label' =>__( 'Recipe', 'spyropress' ) );
        $this->templates['view']   = array( 'view' => 'view.php', 'label' =>__( 'Recipe List', 'spyropress' ) );
        $this->templates['view-three']   = array( 'view' => 'view-three.php', 'label' =>__( 'Recipe Masonry', 'spyropress' ) );
        $this->templates['view-one']   = array( 'view' => 'view-one.php', 'label' =>__( 'Recipe Feature', 'spyropress' ) );
        
        // Fields
        $this->fields = array(
            
            array(
                'label' => __( 'Template', 'spyropress' ),
                'id' => 'template',
                'class' => 'enable_changer section-full',
                'type' => 'select',
                'options' => $this->get_option_templates()
            ),
            
            array(
                'label' => __( 'Title', 'spyropress' ),
                'id' => 'spyropress_title',
                'class' => 'template view-one section-full',
                'type' => 'text'
            ),
            
            array(
                'label'   => __( 'Number of Column', 'spyropress' ),
                'type'    => 'select',
                'class' => 'template view section-full',
                'id' => 'spyropress_columns',
                'options' => array(
                    2 => __( 'Two columns', 'spyropress' ),
                    3 => __( 'Three columns', 'spyropress' ),
                    4 => __( 'Four columns', 'spyropress' ),
                ),'std' => 4
            ),
            
            array(
                'label' => __( 'Number of items per page', 'spyropress' ),
                'type'  => 'range_slider',
                'id' => 'limit',
                'max'   => 30,
                'std'   => 4
            ),
            
            array(
                'label' => __( 'Recipes Category', 'spyropress' ),
                'type' => 'multi_select',
                'id' => 'cat',
                'options' => spyropress_get_taxonomies( 'recipe_category' )
            )
                   
        );
        
        $this->create_widget();
    }
    
    function widget( $spyropress_args, $spyropress_instance ) {

        // extracting info
        extract( $spyropress_args ); extract( $spyropress_instance );
        
        //Templates
        $spyropress_template = isset( $spyropress_instance['template'] ) ? $spyropress_instance['template'] : '';
        
        // get view to render
        include $this->get_view( $spyropress_template );
    }
    
    function spyropress_query( $spyropress_atts, $spyropress_content = null ) {

        $spyropress_default = array (
            'post_type' => 'recipe',
            'limit' => -1,
            'pagination' => false,
        );
        $spyropress_atts = wp_parse_args( $spyropress_atts, $spyropress_default );

        if ( ! empty( $spyropress_atts['cat'] ) ) {

            $spyropress_atts['tax_query']['relation'] = 'OR';
            if ( ! empty( $spyropress_atts['cat'] ) ) {
                $spyropress_atts['tax_query'][] = array(
                    'taxonomy' => 'recipe_category',
                    'field' => 'slug',
                    'terms' => $spyropress_atts['cat'],
                    );
                unset( $spyropress_atts['cat'] );
            }
        }

        if ( $spyropress_content )
            return token_repalce( $spyropress_content, spyropress_query_generator( $spyropress_atts ) );

        return spyropress_query_generator( $spyropress_atts );
    }
    
    function spyropress_generate_items_one( $post_ID, $atts  ){
        
        //recipe meta information.
        $spyropress_data = get_post_meta( $post_ID, '_recipe_details', true );
        
        $spyropress_reviews = '';
        if( isset( $spyropress_data['star'] ) ){
            $spyropress_stars = '';
            //Rating logic.
            $spyropress_star = 5 - $spyropress_data['star'];
            //Diactive Star
            for( $i=0; $i < $spyropress_star; $i++ ){
                $spyropress_stars .= '<span class="fa fa-star"></span>';    
            }
            //Active Star
            for( $j=0; $j < $spyropress_data['star']; $j++ ){
                $spyropress_stars .= '<span class="fa fa-star active"></span>';    
            }
            
            $spyropress_reviews .= '<div class="rc-ratings">'. $spyropress_stars .'</div>';
        }
        
        
                
        //return HTML.
        return '
        <div class="'. esc_attr( $atts['column_class'] ) .'">
            <a href="'.get_the_permalink().'">'. get_image( array( 'echo' => false ) ) .'</a>
            <div class="rc-info">
                <h4>'. get_the_title() .'</h4>
                '. $spyropress_reviews .'
                '. spyropress_get_excerpt( false, $post_ID ) .'
            </div>
        </div>';
        
    }
    
    function spyropress_generate_items_two( $post_ID, $atts  ){
        
        //recipe meta information.
        $spyropress_data = get_post_meta( $post_ID, '_recipe_details', true );
        
        $spyropress_reviews = '';
        if( isset( $spyropress_data['star'] ) ){
            $spyropress_stars = '';
            //Rating logic.
            $spyropress_star = 5 - $spyropress_data['star'];
            //Diactive Star
            for( $i=0; $i < $spyropress_star; $i++ ){
                $spyropress_stars .= '<span class="fa fa-star"></span>';    
            }
            //Active Star
            for( $j=0; $j < $spyropress_data['star']; $j++ ){
                $spyropress_stars .= '<span class="fa fa-star active"></span>';    
            }
            
            $spyropress_reviews .= '<div class="rc-ratings">'. $spyropress_stars .'</div>';
        }
        
        
                
        //return HTML.
        return '
        <div class="fp-content">
            <a href="'. get_permalink() .'">
                '. get_image( array( 'echo' => false ) ) .'
                <h4>'. get_the_title() .'</h4>
            </a>
            '. $spyropress_reviews .'
        </div>';
        
    }
    
    function spyropress_generate_items_three( $post_ID, $atts  ){
        
        //recipe meta information.
        $spyropress_data = get_post_meta( $post_ID, '_recipe_details', true );
        
        $spyropress_reviews = '';
        if( isset( $spyropress_data['star'] ) ){
            $spyropress_stars = '';
            //Rating logic.
            $spyropress_star = 5 - $spyropress_data['star'];
            //Diactive Star
            for( $i=0; $i < $spyropress_star; $i++ ){
                $spyropress_stars .= '<span class="fa fa-star"></span>';    
            }
            //Active Star
            for( $j=0; $j < $spyropress_data['star']; $j++ ){
                $spyropress_stars .= '<span class="fa fa-star active"></span>';    
            }
            
            $spyropress_reviews .= '<div class="rc-ratings">'. $spyropress_stars .'</div>';
        }
        
        
                
        //return HTML.
        return '
        <div class="col-md-6 col-sm-6">
            <a href="'.get_the_permalink().'">'. get_image( array( 'echo' => false ) ) .'</a>
            <div class="rc-info">
                <h4>'. get_the_title() .'</h4>
                '. $spyropress_reviews .'
                '. spyropress_get_excerpt( false, $post_ID ) .'
            </div>
        </div>';
        
    }
    
    function spyropress_generate_items_four( $post_ID, $atts  ){
        
        //recipe meta information.
        $spyropress_data = get_post_meta( $post_ID, '_recipe_details', true );
        
        $spyropress_reviews = '';
        if( isset( $spyropress_data['star'] ) ){
            $spyropress_stars = '';
            //Rating logic.
            $spyropress_star = 5 - $spyropress_data['star'];
            //Diactive Star
            for( $i=0; $i < $spyropress_star; $i++ ){
                $spyropress_stars .= '<span class="fa fa-star"></span>';    
            }
            //Active Star
            for( $j=0; $j < $spyropress_data['star']; $j++ ){
                $spyropress_stars .= '<span class="fa fa-star active"></span>';    
            }
            
            $spyropress_reviews .= '<div class="rc-ratings">'. $spyropress_stars .'</div>';
        }
        
        
                
        //return HTML.
        return '
        <div class="recipie-item">
            <a href="'.get_the_permalink().'">'. get_image( array( 'echo' => false ) ) .'</a>
            <div class="rc-info">
                <h4>'. get_the_title() .'</h4>
                '. $spyropress_reviews .'
                '. spyropress_get_excerpt( false, $post_ID ) .'
            </div>
        </div>';
        
    }
}
//Register Class Spyropress_Module_Recipes.
spyropress_builder_register_module( 'Spyropress_Module_Recipes' );