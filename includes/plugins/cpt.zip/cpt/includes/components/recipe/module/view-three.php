<?php
    // Setup Instance for view
    $spyropress_instance = spyropress_clean_array( $spyropress_instance );
    $spyropress_instance['callback'] = array( $this, 'spyropress_generate_items_four' );
    $spyropress_instance['columns'] = false;
    $spyropress_instance['row'] = false;
    
    //Get Post Contents.
    $spyropress_output = $this->spyropress_query( $spyropress_instance );

?>
<div class="recipie-content recipie-content2">
    <div class="recipie-items">
        <?php echo $spyropress_output['content']; //Module Contents. ?>
    </div>
</div> 
        
        