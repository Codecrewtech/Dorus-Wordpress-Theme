<?php
/**
 * Recipe Component
 * 
 * @package		SpyroPress
 * @category	Components
 */

class SpyropressRecipe extends SpyropressComponent {

    private $path;
    
    function __construct() {

        $this->path = dirname(__FILE__);
        add_action( 'spyropress_register_taxonomy', array( $this, 'register' ) );
        add_filter( 'builder_include_modules', array( $this, 'register_module' ) );
    }

    function register() {

        // Init Post Type
        $args = array(
            'supports' => array( 'title', 'thumbnail', 'editor', 'excerpt' ),
            'title' => __( 'Enter Recipe Name here', 'spyropress' ),
            'has_archive'   => false,
            'exclude_from_search' => true
        );
        $post = new SpyropressCustomPostType( __( 'Recipe', 'spyropress' ), 'recipe', $args );
        
        // Add Taxonomy
        $post->add_taxonomy( __( 'Recipe Category', 'spyropress' ), 'recipe_category', __( 'Recipe Categories', 'spyropress' ), array( 'hierarchical' => true ) );
          
        // Add Meta Boxes
        $meta_fields['recipe'] = array(
            array(
                'label' => 'Recipe',
                'type' => 'heading',
                'slug' => 'recipe'
            ),
            
            array(
                'label' => __( 'Star rating', 'spyropress' ),
                'id' => 'star',
                'class' => 'section-full',
                'type' => 'range_slider',
                'std' => 3,
                'max' => 5
            ),
            
            array(
                'label' => esc_html__( 'Ingredients List', 'sonno' ),
                'type' => 'sub_heading'
            ),
            
            array(
                'label' => __( 'Ingredients List', 'sonno' ),
                'type' => 'repeater',
                'id' => 'ingredients',
                'item_title' => 'ingredients_item',
                'hide_label' => true,
                'fields' => array(
                    array(
                		'label' => __( 'List Item', 'spyropress' ),
                        'id' => 'ingredients_item',
                        'type' => 'text',
                	)
                )
             ),
             
            array(
                'label' => esc_html__( 'Direction List', 'sonno' ),
                'type' => 'sub_heading'
            ),
            
            array(
                'label' => __( 'Direction List', 'sonno' ),
                'type' => 'repeater',
                'id' => 'directions',
                'item_title' => 'direction_item',
                'hide_label' => true,
                'fields' => array(
                
                    array(
                		'label' => __( 'List Item', 'spyropress' ),
                        'id' => 'direction_item',
                        'type' => 'textarea',
                        'rows' => 3
                	)
                )
             ),
             
            array(
                'label' => esc_html__( 'Descriptions', 'sonno' ),
                'type' => 'sub_heading'
            ),
            
            array(
        		'label' => __( 'Descriptions', 'spyropress' ),
                'id' => 'descriptions',
                'class' => 'section-full',
                'type' => 'textarea',
                'rows' => 3
        	),
            
            array(
                'label' => esc_html__( 'Nutrition', 'sonno' ),
                'type' => 'sub_heading'
            ),
            
            array(
                'label' => __( 'Nutrition List', 'sonno' ),
                'type' => 'repeater',
                'id' => 'nutritions',
                'item_title' => 'nutrient',
                'hide_label' => true,
                'fields' => array(
                
                    array(
                		'label' => __( 'Nutrient', 'spyropress' ),
                        'id' => 'nutrient',
                        'type' => 'text'
                	),
                    array(
                		'label' => __( 'DV', 'spyropress' ),
                        'id' => 'dv',
                        'type' => 'text'
                	),
                    array(
                		'label' => __( '%DV', 'spyropress' ),
                        'id' => 'dv_percentage',
                        'type' => 'range_slider',
                        'max' => '10',
                	)
                )
             ),
             
             array(
                'label' => esc_html__( 'Display', 'sonno' ),
                'type' => 'sub_heading'
            ),
             
             array(
                'id' => 'display',
                'class' => 'section-full',
                'desc' => __( 'Select the option to display','sonno' ),
                'class' => 'enable_changer section-full',
                'type' => 'select',
                'options' => array( 'gallery' => 'Gallery', 'video' => 'Video' )
            ),

            array(
                'label' => __( 'Video','sonno' ),
                'id' => 'video',
                'class' => 'section-full',
                'desc' => __( 'This enable you to embed videos into your portfolio pages.','sonno' ),
                'class' => 'display video',
                'type' => 'textarea',
                'rows' =>  3
            ),

            array(
                'label' => __( 'Gallery','sonno' ),
                'id' => 'gallery',
                'class' => 'section-full',
                'desc' => __( 'Set up your gallery.','sonno' ),
                'class' => 'display gallery',
                'type' => 'gallery'
            )
        );
        
        $post->add_cpt_meta_box( 'recipe', __( 'Recipe Details', 'spyropress' ), $meta_fields, '_recipe_details', false );
    }
    
    function register_module( $modules ) {

        $modules[] = $this->path . '/module/module.php';

        return $modules;
    }
}

/**
 * Init the Component
 */
new SpyropressRecipe();