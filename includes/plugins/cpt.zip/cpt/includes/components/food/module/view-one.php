<?php
    // Setup Instance for view
    $spyropress_instance = spyropress_clean_array( $spyropress_instance );
    $spyropress_instance['callback'] = array( $this, 'spyropress_generate_items_two' );
    $spyropress_instance['row'] = false;
    $spyropress_instance['columns'] = $spyropress_columns;
    $spyropress_instance['column_class'] = 'menu-item3';
    
    
    //filter for category.
    $spyropress_filters = ( isset( $spyropress_instance['settings'] ) && in_array( 'filter', $spyropress_instance['settings'] ) ) ? true : false;
    $spyropress_filter = '';
    if( !empty( $spyropress_filters ) ){
        $spyropress_terms = get_terms( 'food_category', array( 'slug' => $cat ) );
        if( !empty( $spyropress_terms ) && !is_wp_error( $spyropress_terms ) ) {
            $spyropress_filter .= '<div class="row"><div class="col-md-12"><div class="menu-tags">';
            if(!empty($spyropress_all_btn))
                $spyropress_filter .= '<span data-filter="*" class="tagsort-active">'. $spyropress_all_btn .'</span>';
            foreach( $spyropress_terms as $spyropress_item ):
                $spyropress_filter .= '<span data-filter=".' . $spyropress_item->slug . '">' . esc_html( $spyropress_item->name ) . '</span>';
            endforeach;
            
            $spyropress_filter .= '</div></div></div>';
    
        }
    }
    
    //Get Post Contents.
    $spyropress_output = $this->spyropress_query( $spyropress_instance );

?>
<div class="menu">
    <div class="food-menu" <?php echo spyropress_build_atts( array( 'animation' => esc_attr( $spyropress_animation ) , 'animation-delay' => esc_attr( $spyropress_delay ) ), 'data-' ); ?>>
        <?php echo $spyropress_filter; //Module Filter ?>
        <div class="row menu-items3"> 
            <?php echo $spyropress_output['content']; //Module Contents. ?>
        </div> 
        <?php if( $spyropress_url ): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="menu-btn">
                        <a class="btn btn-default btn-lg" href="<?php echo esc_url( $spyropress_url );?>" ><?php echo esc_html( $spyropress_btn_text );?></a>
                    </div>
                </div>
            </div>  
        <?php endif; ?>
    </div>
</div>