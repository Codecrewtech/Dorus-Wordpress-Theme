<?php
/**
 * Module: Food Menu
 * Add Food Dishes Menu items into the page layout wherever needed.
 */
class Spyropress_Module_Food_Item extends SpyropressBuilderModule {
    
    public function __construct() {
        
        // Widget variable settings.
        $this->path = dirname( __FILE__ );
        $this->cssclass = 'spyropress_food_item';
        $this->description = __( 'Add Food Dishes Menu items into the page layout wherever needed.', 'spyropress' );
        $this->id_base = 'spyropress_food_item';
        $this->name = __( 'Food Dishes Menu', 'spyropress' );
        
        //template.
        $this->templates['view']   = array( 'view' => 'view.php', 'label' =>__( 'Menu - List', 'spyropress' ) );
        $this->templates['view-one']   = array( 'view' => 'view-one.php', 'label' =>__( 'Menu - Tile', 'spyropress' ) );
        $this->templates['view-two'] = array( 'view' => 'view-two.php', 'label' =>__( 'Menu - Overlay', 'spyropress' ) );        
        $this->templates['view-three'] = array( 'view' => 'view-three.php', 'label' =>__( 'Menu - Grid', 'spyropress' ) );        
        
        // Fields
        $this->fields = array(
        
            array(
                'label' => __( 'Template', 'spyropress' ),
                'id' => 'template',
                'class' => 'enable_changer section-full',
                'type' => 'select',
                'options' => $this->get_option_templates()
            ),
            
        
            array(
                'label'   => __( 'Number of Column', 'spyropress' ),
                'type'    => 'select',
                'id' => 'spyropress_columns',
                'options' => array(
                    2 => __( 'Two columns', 'spyropress' ),
                    3 => __( 'Three columns', 'spyropress' ),
                    4 => __( 'Four columns', 'spyropress' ),
                ),'std' => 4
            ),
            
            array(
                'label' => __( 'Number of items per page', 'spyropress' ),
                'type'  => 'range_slider',
                'id' => 'limit',
                'max'   => 30,
                'std'   => 4
            ),
            
            array(
                'label' => __( 'Food Category', 'spyropress' ),
                'type' => 'multi_select',
                'id' => 'cat',
                'options' => spyropress_get_taxonomies( 'food_category' )
            ),
            
            array(
                'label' => __('Filter', 'spyropress'),
                'id' => 'settings',
                'type' => 'checkbox',
                'desc' => 'Will show filter of Food Dishes Menu.',
                'options' => array(
                    'filter' => __( 'Enable filter of Food Dishes Menu','spyropress' ), 
                )
            ),
            
           array(
            'label' => __( 'All', 'spyropress' ),
            'id' => 'spyropress_all_btn',
                'type' => 'text',
                'std' => 'All'
           ),
            
            array(
                'label' => __( 'Button', 'spyropress' ),
                'type' => 'toggle',
            ),
            
                array(
                    'label' => __( 'Button Text', 'spyropress' ),
                    'id' => 'spyropress_btn_text',
                    'type' => 'text'
                ),
                
                array(
                    'label' => __( 'Button Url', 'spyropress' ),
                    'id' => 'spyropress_url',
                    'type' => 'text'
                ),
                
            array(
                'type' => 'toggle_end'
            ), 
            array(
                'label' => __( 'Animation', 'spyropress' ),
                'type' => 'toggle',
            ),
            
                array(
                    'label' => __( 'Animation', 'spyropress' ),
                    'id' => 'spyropress_animation',
                    'type' => 'select',
                    'options' => spyropress_get_options_animation()
                ),
                
                array(
                    'label' => __( 'Delay', 'spyropress' ),
                    'id' => 'spyropress_delay',
                    'type' => 'text'
                ),
                
            array(
                'type' => 'toggle_end'
            ) 
                   
        );
        
        $this->create_widget();
    }
    
    function widget( $spyropress_args, $spyropress_instance ) {

        // extracting info
        extract( $spyropress_args ); extract( $spyropress_instance );
        
        //Templates
        $spyropress_template = isset( $spyropress_instance['template'] ) ? $spyropress_instance['template'] : '';
        
        // get view to render
        include $this->get_view( $spyropress_template );
    }
    
    function spyropress_query( $spyropress_atts, $spyropress_content = null ) {

        $spyropress_default = array (
            'post_type' => 'food',
            'limit' => -1,
            'pagination' => false,
        );
        $spyropress_atts = wp_parse_args( $spyropress_atts, $spyropress_default );

        if ( ! empty( $spyropress_atts['cat'] ) ) {

            $spyropress_atts['tax_query']['relation'] = 'OR';
            if ( ! empty( $spyropress_atts['cat'] ) ) {
                $spyropress_atts['tax_query'][] = array(
                    'taxonomy' => 'food_category',
                    'field' => 'slug',
                    'terms' => $spyropress_atts['cat'],
                    );
                unset( $spyropress_atts['cat'] );
            }
        }

        if ( $spyropress_content )
            return token_repalce( $spyropress_content, spyropress_query_generator( $spyropress_atts ) );

        return spyropress_query_generator( $spyropress_atts );
    }
    
    function spyropress_generate_items_one( $post_ID, $atts  ){
        
        //get meta information.
        $spyropress_data = get_post_meta( $post_ID, '_food_details', true );
        
        //post tags.
        $spyropress_terms = get_the_terms( $post_ID, 'food_category' );
        $spyropress_cats = array();
        if ( !is_wp_error( $spyropress_terms ) && !empty( $spyropress_terms ) ) {
            foreach ( $spyropress_terms as $spyropress_term ) {
                $spyropress_cats[] = $spyropress_term->slug;
            }
        } 
        
        
        //get post meta data content.
        $spyropress_currency = isset( $spyropress_data['spyropress_currency'] )? $spyropress_data['spyropress_currency'] : '$';
        $spyropress_price = isset( $spyropress_data['spyropress_price'] )? '<span class="price">'. esc_html( $spyropress_currency ) .' '. esc_html( $spyropress_data['spyropress_price'] ) . '</span>' : '';
        $spyropress_description = isset( $spyropress_data['spyropress_description'] )? '<p>'. esc_html( $spyropress_data['spyropress_description'] ) .'</p>' : '';
       
                
        //return HTML.
        return '
        <div class="'. esc_attr( $atts['column_class'] ) .' '. join( ' ', $spyropress_cats ) .'">
            <div class="clearfix menu-wrapper">
                <h4>'. get_the_title() .'</h4>
                '. $spyropress_price .'
                <div class="dotted-bg"></div>
            </div>
            '. $spyropress_description .'
        </div>';
        
    }
    
    function spyropress_generate_items_two( $post_ID, $atts  ){
        
        //get meta information.
        $spyropress_data = get_post_meta( $post_ID, '_food_details', true );
        
        //post tags.
        $spyropress_terms = get_the_terms( $post_ID, 'food_category' );
        $spyropress_cats = array();
        if ( !is_wp_error( $spyropress_terms ) && !empty( $spyropress_terms ) ) {
            foreach ( $spyropress_terms as $spyropress_term ) {
                $spyropress_cats[] = $spyropress_term->slug;
            }
        } 
        
        
        //get post meta data content.
        $spyropress_currency = isset( $spyropress_data['spyropress_currency'] )? $spyropress_data['spyropress_currency'] : '$';
        $spyropress_price = isset( $spyropress_data['spyropress_price'] )? '<span class="price">'. esc_html( $spyropress_currency ) .' '. esc_html( $spyropress_data['spyropress_price'] ) . '</span>' : '';
        $spyropress_description = isset( $spyropress_data['spyropress_description'] )? '<p>'. esc_html( $spyropress_data['spyropress_description'] ) .'</p>' : '';
       
                
        //return HTML.
        return '
        <div class="'. esc_attr( $atts['column_class'] ) .' '. join( ' ', $spyropress_cats ) .'">
            <a href="#" data-mfp-src="'. get_image( array( 'type' => 'src', 'echo' => false ) ) .'" class="gallery-item"  data-rel="prettyPhoto" title="'. get_the_title() .'">'. get_the_post_thumbnail( $post_ID, 'thumbnail' ) .'</a>
            <div class="menu-wrapper">
                <h4>'. get_the_title() .'</h4>
                '. $spyropress_price .'
                <div class="dotted-bg"></div>
                '. $spyropress_description .'
            </div>
        </div>';
        
    }
    
    function spyropress_generate_items_three( $post_ID, $atts  ){
        
        //get meta information.
        $spyropress_data = get_post_meta( $post_ID, '_food_details', true );
        
        //post tags.
        $spyropress_terms = get_the_terms( $post_ID, 'food_category' );
        $spyropress_cats = array();
        if ( !is_wp_error( $spyropress_terms ) && !empty( $spyropress_terms ) ) {
            foreach ( $spyropress_terms as $spyropress_term ) {
                $spyropress_cats[] = $spyropress_term->slug;
            }
        } 
        
        
        //get post meta data content.
        $spyropress_currency = isset( $spyropress_data['spyropress_currency'] )? $spyropress_data['spyropress_currency'] : '$';
        $spyropress_price = isset( $spyropress_data['spyropress_price'] )? '<span class="price">'. esc_html( $spyropress_currency ) .' '. esc_html( $spyropress_data['spyropress_price'] ) . '</span>' : '';
        $spyropress_description = isset( $spyropress_data['spyropress_description'] )? '<p>'. esc_html( $spyropress_data['spyropress_description'] ) .'</p>' : '';
       
                
        //return HTML.
        return '
        <div class="'. esc_attr( $atts['column_class'] ) .' '. join( ' ', $spyropress_cats ) .'">
            <div class="menu-info">
                <a href="#" data-mfp-src="'. get_image( array( 'type' => 'src', 'echo' => false ) ) .'"  class="gallery-item" data-rel="prettyPhoto" title="'. get_the_title() .'">'. get_image( array( 'class' => 'img-responsive', 'echo' => false ) ) .'</a>
                <a href="'. get_permalink() .'">
                    <div class="menu2-overlay">
                        <h4>'. get_the_title() .'</h4>
                        '. $spyropress_description .'
                        '. $spyropress_price .'
                    </div>
                </a>
            </div>
            <a href="'. get_permalink() .'" class="menu-more">+</a>
        </div>';
        
    }
    
    function spyropress_generate_items_four( $post_ID, $atts  ){
        
        //get meta information.
        $spyropress_data = get_post_meta( $post_ID, '_food_details', true );
        
        //post tags.
        $spyropress_terms = get_the_terms( $post_ID, 'food_category' );
        $spyropress_cats = array();
        if ( !is_wp_error( $spyropress_terms ) && !empty( $spyropress_terms ) ) {
            foreach ( $spyropress_terms as $spyropress_term ) {
                $spyropress_cats[] = $spyropress_term->slug;
            }
        } 
        
        
        //get post meta data content.
        $spyropress_currency = isset( $spyropress_data['spyropress_currency'] )? $spyropress_data['spyropress_currency'] : '$';
        $spyropress_price = isset( $spyropress_data['spyropress_price'] )? '<span class="price">'. esc_html( $spyropress_currency ) .' '. esc_html( $spyropress_data['spyropress_price'] ) . '</span>' : '';
        $spyropress_description = isset( $spyropress_data['spyropress_description'] )? '<p>'. esc_html( $spyropress_data['spyropress_description'] ) .'</p>' : '';
       
                
        //return HTML.
        return '
        <div class="'. esc_attr( $atts['column_class'] ) .' '. join( ' ', $spyropress_cats ) .'">
            <div class="menu-info">
                <a href="#" data-mfp-src="'. get_image( array( 'type' => 'src', 'echo' => false ) ) .'" class="gallery-item"   data-rel="prettyPhoto" title="'. get_the_title() .'">'. get_image( array( 'class' => 'img-responsive', 'echo' => false ) ) .'</a>
                <a href="'. get_permalink() .'">
                    <div class="menu4-overlay">
                        <h4>'. get_the_title() .'</h4>
                        '. $spyropress_description .'
                        '. $spyropress_price .'
                    </div>
                </a>
            </div>
        </div>';
        
    }
    
}
//Register Class Spyropress_Module_Food_Item.
spyropress_builder_register_module( 'Spyropress_Module_Food_Item' );