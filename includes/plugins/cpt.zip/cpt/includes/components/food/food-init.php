<?php
/**
 * Food Dish Component
 * 
 * @package		SpyroPress
 * @category	Components
 */

class SpyropressFood extends SpyropressComponent {

    private $path;
    
    function __construct() {

        $this->path = dirname(__FILE__);
        add_action( 'spyropress_register_taxonomy', array( $this, 'register' ) );
        add_filter( 'builder_include_modules', array( $this, 'register_module' ) );
    }

    function register() {

        // Init Post Type
        $args = array(
            'supports' => array( 'title', 'thumbnail' ),
            'title' => __( 'Enter Food Name Dish here', 'spyropress' ),
            'has_archive'   => false,
            'exclude_from_search' => true
        );
        $post = new SpyropressCustomPostType( __( 'Food', 'spyropress' ), 'food', $args );
        
        // Add Taxonomy
        $post->add_taxonomy( __( 'Food Category', 'spyropress' ), 'food_category', __( 'Food Categories', 'spyropress' ), array( 'hierarchical' => true ) );
          
        // Add Meta Boxes
        $meta_fields['food'] = array(
            array(
                'label' => 'Food',
                'type' => 'heading',
                'slug' => 'food'
            ),
            
            array( 'type' => 'row' ),

                array( 'type' => 'col', 'size' => 6 ),
                   
                   array(
                        'title' => __('Currency', 'spyropress'),
                		'type' => 'text',
                        'id' => 'spyropress_currency',
                        'std' => '$',
                        'desc' => __( 'Insert the currency.', 'spyropress' )
                	),   
            
            
                array( 'type' => 'col_end' ),

                array( 'type' => 'col', 'size' => 6 ),
                    
                    array(
                        'title' => __('Price', 'spyropress'),
                		'type' => 'text',
                        'id' => 'spyropress_price',
                        'desc' => __( 'Insert the price of food dish.', 'spyropress' )
                	),
                
                array( 'type' => 'col_end' ),

            array( 'type' => 'row_end' ),
            
            array(
                'title' => __('Description', 'spyropress'),
        		'type' => 'textarea',
                'rows' => 4,
                'class' => 'section-full',
                'id' => 'spyropress_description',
        	) 
        );
        
        $post->add_cpt_meta_box( 'food', __( 'Food Dishes Menu Details', 'spyropress' ), $meta_fields, '_food_details', false );
    }
    
    function register_module( $modules ) {

        $modules[] = $this->path . '/module/module.php';

        return $modules;
    }
}

/**
 * Init the Component
 */
new SpyropressFood();