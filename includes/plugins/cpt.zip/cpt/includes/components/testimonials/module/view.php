<?php
// Setup Instance for view
$spyropress_instance = spyropress_clean_array( $spyropress_instance );

//Print Html Contents
echo '<div class="trusted-quote"><div class="col-md-offset-1 col-md-10"><div class="trusted-slider"><ul class="slides">'. $this->query( $spyropress_instance, '{content}' ) .'</ul></div></div></div>';
    
